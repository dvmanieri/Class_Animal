package Time_08;


import java.io.InputStream;
import java.util.Scanner;

public class TesteAnimais {

	public static void main(String[] args) {

		// Criação dos Objetos

		Animais jacare = new Animais(3,48,2125,300,"Jacaré",50);
		Animais onca = new Animais(1.5,80,2000,96,"Onça",15);
		Animais urso = new Animais(2,56,1200,540,"Urso",20);
		Animais tubarao = new Animais(4,56,4000,1100,"Tubarão",70);
		Animais humano = new Animais();
		Scanner scan = new Scanner(System.in);

		// variaveis:
		int navegador;
		int controlador = 1;
		int navegador2 = 0;
		double x;
		double dist;
		double forcaTotal;									
		// Inicia um projeto de um menu

		while (controlador != 0) {

			System.out.println(" ");
			System.out.println("==================  ANIMAIS  =========================");
			System.out.println(" ");
			System.out.println("\t 1 - Características  animais ");
			System.out.println(" ");
			System.out.println("\t 2 - Qual a força total? ");
			System.out.println(" ");
			System.out.println("\t 3 - Descubra o tempo de vida do seu animal ");
			System.out.println(" ");
			System.out.println("\t 4 - Quanto tempo o seu animal levará para percorrer determinada distancia? ");
			System.out.println(" ");
			System.out.println("\t 5 - Sair ");
			System.out.println(" ");

			navegador2 = scan.nextInt();

			// Incluindo os atributos

			humano.setAltura(1.7);
			humano.setMordidaForca(162);
			humano.setPeso(80);
			humano.setVelocidade(13);
			humano.setNome("Humano");
			humano.setTempo(75);

			//cai dentro do 

			if (navegador2 == 1) {
			
				System.out.println("\n \n=====Lista de animais===== \n \n \t1 - Jacaré \n \t2 - Onça \n \t3 - Urso \n \t4 - Tubarão \n \t5 - Humano \n \t6 - Sair \n");

				navegador = scan.nextInt();

				// switch para invocar as funçoes

				switch (navegador) {
				case 1:
				{
					
					//ele chama os atributos por meio do Get.
					
					System.out.println(" ");
					System.out.println(" ");
					System.out.println("      " + jacare.getNome());
					System.out.println("Altura/comprimento: " + jacare.getAltura() + "m");
					System.out.println("Velocidade: " + jacare.getVelocidade() + "Km");
					System.out.println("Força da mordida: " + jacare.getMordidaForca() + "PSI");
					System.out.println("Peso/massa: " + jacare.getPeso() + "Kg");
					System.out.println(" ");
					System.out.println(" ");

				}
					break;

				case 2:
					
				{
					
					System.out.println(" ");
					System.out.println(" ");
					System.out.println("      " + onca.getNome());
					System.out.println("Altura/comprimento: " + onca.getAltura() + "m");
					System.out.println("Velocidade: " + onca.getVelocidade() + "Km");
					System.out.println("Força da mordida: " + onca.getMordidaForca() + "PSI");
					System.out.println("Peso/massa: " + onca.getPeso() + "Kg");
					System.out.println(" ");
					System.out.println(" ");

				}
					break;
				case 3:
					System.out.println(" ");
					System.out.println(" ");
					System.out.println("      " + urso.getNome());
					System.out.println("Altura/comprimento: " + urso.getAltura() + "m");
					System.out.println("Velocidade: " + urso.getVelocidade() + "Km");
					System.out.println("Força da mordida: " + urso.getMordidaForca() + "PSI");
					System.out.println("Peso/massa: " + urso.getPeso() + "Kg");
					System.out.println(" ");
					System.out.println(" ");
					
					
				case 4:
					
					System.out.println(" ");
					System.out.println(" ");
					System.out.println("      " + tubarao.getNome());
					System.out.println("Altura/comprimento: " + tubarao.getAltura() + "m");
					System.out.println("Velocidade: " + tubarao.getVelocidade() + "Km");
					System.out.println("Força da mordida: " + tubarao.getMordidaForca() +"PSI");
					System.out.println("Peso/massa: " + tubarao.getPeso() + "Kg");
					System.out.println(" ");
					System.out.println(" ");
					
				case 5:
					
					System.out.println(" ");
					System.out.println(" ");
					System.out.println("      " + humano.getNome());
					System.out.println("Altura/comprimento: " + humano.getAltura() + "m");
					System.out.println("Velocidade: " + humano.getVelocidade() + "Km");
					System.out.println("Força da mordida: " + humano.getMordidaForca() + "PSI");
					System.out.println("Peso/massa: " + humano.getPeso() + "Kg");
					System.out.println(" ");
					System.out.println(" ");
					break;

				default:
					System.out.println("Error!!!!!!!!!!!");
				}

			}

			if (navegador2 == 2) {
				
				System.out.println("\n \n=====Lista de animais===== \n \n \t1 - Jacaré \n \t2 - Onça \n \t3 - Urso \n \t4 - Tubarão \n \t5 - Humano \n \t6 - Sair \n");

				navegador = scan.nextInt();
				//switch para navegar entre as opções
				switch (navegador) {
				case 1:
					//soma algumas das caracteristicas do animais
					forcaTotal = (jacare.getAltura() + jacare.getPeso() + jacare.getMordidaForca())/3;
					System.out.println(forcaTotal);
					break;
				case 2:
					forcaTotal = (onca.getAltura() + onca.getPeso() + onca.getMordidaForca())/3;
					System.out.println(forcaTotal);
					break;
				case 3:
					forcaTotal = (urso.getAltura() + urso.getPeso() +urso.getMordidaForca())/3;
					System.out.println(forcaTotal);
					break;
				case 4:
					forcaTotal = (tubarao.getAltura() + tubarao.getPeso() +tubarao.getMordidaForca())/3;
					
					System.out.println(forcaTotal);
					break;
				case 5:
					forcaTotal = (humano.getAltura() + humano.getPeso() +humano.getMordidaForca())/3;
					System.out.println(forcaTotal);
					break;
				default:
					System.out.println("Error!!!!!!!!!!!");

				}

			}
			if (navegador2 == 3) {
				
				System.out.println("\n \n=====Lista de animais===== \n \n \t1 - Jacaré \n \t2 - Onça \n \t3 - Urso \n \t4 - Tubarão \n \t5 - Humano \n \t6 - Sair \n");

				navegador = scan.nextInt();

				switch (navegador) {
				case 1:
					//fala sobre o tempo de vida dos animais
					System.out.println("o jacaré vive por " +jacare.getTempo()+" anos ");
					break;

				case 2:
					System.out.println("a onça vive por " + onca.getTempo()+" anos ");
					break;
				case 3:
					System.out.println("o urso vive por " +urso.getTempo()+" anos ");
					break;
				case 4:
					System.out.println("o tubarão vive por " +tubarao.getTempo()+" anos ");
					break;
				case 5:
					System.out.println("o humano vive por " +humano.getTempo()+" anos ");
					break;

				default:
					System.out.println("Error!!!!!!!!!!!");
				}

			}
			if (navegador2 == 4) {
		
				System.out.println("\n \n =====Lista de animais===== \n \n 1 - Jacaré \n  2 - Onça \n  3 - Urso \n  4 - Tubarão \n  5 - Humano \n  6 - Sair \n");

				navegador = scan.nextInt();
				
				System.out.println(" ");
				
				System.out.println("Digite a distância que seu animal percorreu: ");
				System.out.println(" ");
				
				dist = scan.nextDouble();
				
				switch (navegador) {
				
				case 1:
					//calcula a velocidade média
					double tempoVM = (dist/jacare.getVelocidade())*60;
					
					System.out.println(" ");
					System.out.println("Seu animal levará " + tempoVM+ " minutos para percorrer " 					+ dist + " metros.");
					break;

				case 2:
					
							tempoVM = (dist/onca.getVelocidade())*60;
					
					System.out.println(" ");
					System.out.println("Seu animal levará " + tempoVM+ " minutos para percorrer " 					+ dist + " metros.");
					break;

				case 3:
					
							tempoVM = (dist/urso.getVelocidade())*60;
					
					System.out.println(" ");
					System.out.println("Seu animal levará " + tempoVM+ " minutos para percorrer " 					+ dist + " metros.");
					break;

				case 4:
					
							tempoVM = (dist/tubarao.getVelocidade())*60;
					
					System.out.println(" ");
					System.out.println("Seu animal levará " + tempoVM+ " minutos para percorrer " 					+ dist + " metros.");
					break;

				case 5:
					
							tempoVM = (dist/humano.getVelocidade())*60;
					
					System.out.println(" ");
					System.out.println("Seu animal levará " + tempoVM+ " minutos para percorrer " 					+ dist + " metros.");
					break;

				default:
					
					System.out.println("\nError!!!!!!!!!! \n");

				}

			}
			if (navegador2 == 5) {
				break;
			}

		}
	}

}
