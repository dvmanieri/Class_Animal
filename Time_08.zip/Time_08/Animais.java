package Time_08;
/*
 * Davi Manieri
 * Lucas Oliveira
 * Luiz Miguel
 * Rhuan
 */
public class Animais {
	//atributos private
	private double altura;
	private int velocidade;
	private double MordidaForca;
	private double peso;
	private String nome;
	private int tempo;
	
	//metodo contrutor
	public Animais() {}
	
	public Animais(double altura, int velocidade, double mordidaForca, double peso, String nome, int tempo) {
		super();
		this.altura = altura;
		this.velocidade = velocidade;
		MordidaForca = mordidaForca;
		this.peso = peso;
		this.nome = nome;
		this.tempo = tempo;
	}
	//metodos sett e gett 
	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public int getVelocidade() {
		return velocidade;
	}

	public void setVelocidade(int velocidade) {
		this.velocidade = velocidade;
	}

	public double getMordidaForca() {
		return MordidaForca;
	}

	public void setMordidaForca(double mordidaForca) {
		MordidaForca = mordidaForca;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getTempo() {
		return tempo;
	}

	public void setTempo(int tempo) {
		this.tempo = tempo;
	}	
}
